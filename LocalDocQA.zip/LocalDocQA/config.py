# config.py

appid = "你的讯飞 APPID"
api_key = "你的 APIKey"
api_secret = "你的 APISecret"